package com.amdocs.controller;

import java.util.HashMap;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.controller.*;
import com.amdocs.exception.*;
import com.amdocs.model.*;
import com.amdocs.repository.*;

@RestController
@RequestMapping("/api/v1_doctor")
public class DoctorController {

    @Autowired
    private DoctorRepository doctorRepository;

    @GetMapping("/doctors")
    public List<DoctorInfo> getAllDoctor() {
        return doctorRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<DoctorInfo> getDoctorById(@PathVariable int id) {
        DoctorInfo doctorInfo = doctorRepository.findById((long) id).orElse(null);

        if (doctorInfo == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(doctorInfo);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteDoctorById(@PathVariable int id) {

        doctorRepository.deleteById((long) id);
        return ResponseEntity.ok("DoctorInfo deleted successfully");
    }
}
