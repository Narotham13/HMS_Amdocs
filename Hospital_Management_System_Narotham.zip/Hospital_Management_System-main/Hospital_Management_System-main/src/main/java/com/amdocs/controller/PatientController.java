package com.amdocs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.controller.*;
import com.amdocs.exception.*;
import com.amdocs.model.*;
import com.amdocs.repository.*;

@RestController
@RequestMapping("/api/v1_patient")
public class PatientController {

    @Autowired
    private PatientRepository patientRepository;

    @GetMapping("/patients")
    public List<PatientInfo> getAllPatient() {
        return patientRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PatientInfo> getPatientById(@PathVariable int id) {
        PatientInfo patientInfo = patientRepository.findById((long) id).orElse(null);

        if (patientInfo == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(patientInfo);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deletePatientById(@PathVariable int id) {
        if (!patientRepository.existsById((long) id)) {
            return ResponseEntity.notFound().build();
        }

        patientRepository.deleteById((long) id);
        return ResponseEntity.ok("PatientInfo deleted successfully");
    }
}
